IMG2ARGB utility

(C) 2006 Igor Maznitsa (http://www.igormaznitsa.com)

The utility can convert PNG,GIF or JPG image to either palette indexed array or ARGB array.

com.igormaznitsa.img2argb.main  [/?] [/di] [/argb] [image_name | image_name .. image_name]

/?         - print the help
/di        - save image data for DynamicEngine (add zero byte in the start of every pixel string
/argb      - save image array as ARGB (default 256 palette indexes)
image_name - the name(s) of a converted image(s), array will be saved into the image directory. Warning, if you are processing a few images in the time, the palette will be shared for the images.

You can process single image or a image list (just print image names as arguments). Remember that the palette will be saved in the parent directory of the first image in the list.
If you process images for ARGB arrays their names will be <image_name>.<ext>.argb
If you process images for Dynamic Engine 8bpp, their names will be <image_name>.<ext>.di
If you process images for 256 palette, their names will be <image_name>.<ext>.indexed
The palette file has name <first_image_name>.<ext>.pal
The palette has format (byte) R, (byte) G, (byte) B

