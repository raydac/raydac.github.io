Mobile projects builder
------------------------

(C) 2003-2006 Raydac Research Group Ltd.

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
The tool needs for own work a few utilities from WTK but you can use them only in the context of SUN BINARY LICENSE.
The utilities are
-------------------
preverify.exe
preverify1.0.exe
preverify1.1.exe

you need to place it into the directory of Mobile Project Builder
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
The tool may needs for own work the Proguard Obfuscator. You should download it from proguard.sourceforge.net and place proguard.jar into the root directory of the tool.
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

The tool (Mobile Projects Builder) enable to compile and assemble J2ME projects (one or some at once) so it enables to make preprocessing of source files before compilation.

The compilation process
---------------------------

Execute "before.bat" in the project directory (if it exists) else execute "before.bat" in the projects tree root directory (if it exists) (checking result of the bat file processing)
      |
      V
 Preprocessing of sources
      |
      V
 Compilation of sources
      |
      V
 Obfuscation of compiled classes (if it needs)
      |
      V
 Preverifieng of compiled classes
      |
      V
 Jar packing
      |
      V
 Jar optimization (if it needs)
      |
      V
Execute "after.bat" in the project directory (if it exists) else execute "after.bat" in the projects tree root directory (if it exists) (checking result of the bat file processing)
      
The utility is free and is provided "AS IS".

The "AddLib" directory contains JAR files with needed classes for compilation.
