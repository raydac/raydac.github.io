package com.igormaznitsa.jcpjavassistdemo;

import java.lang.reflect.Method;
import javassist.*;

public class Main 
{

  public static void main(final String ... args) throws Exception {
    final Class<?> clazz = prepare();
    final Object instance = clazz.newInstance();
    final Method extractExt = clazz.getDeclaredMethod("extractExtension", String.class, boolean.class);
    System.out.println("The Example shows how to decrease complexity of usage Javassist with help of JCP");
    System.out.println("-------------------------------------------------------------------------------------");
    System.out.println("Execute with FALSE flag, just return file name: " + extractExt.invoke(instance, "filename.txt", false));
    System.out.println("Execute with TRUE flag, return extracted extension: " + extractExt.invoke(instance, "filename.txt", true));
  }
  
  public static Class<?> prepare() throws Exception {
      final ClassPool cp = ClassPool.getDefault();
      cp.appendClassPath(new LoaderClassPath(Main.class.getClassLoader()));
      final CtClass ctClazz = cp.get(Main.class.getPackage().getName()+".ExtProcessor");
      final CtMethod method1 = ctClazz.getDeclaredMethod("extractExtension");
      method1.insertBefore(
/*$str2java(evalfile("_extractExtensionMethod.java"),true)$*//*-*/""
      );
      ctClazz.writeFile();
      return ctClazz.toClass();
  }
}