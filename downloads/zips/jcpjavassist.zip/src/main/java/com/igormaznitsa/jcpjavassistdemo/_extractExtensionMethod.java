//#excludeif true
//#-
package com.igormaznitsa.jcpjavassistdemo;
public class _extractExtensionMethod {
  public String extractExtension(final String ____arg1, final boolean ____arg2) {
    final String fileName = ____arg1;
    final boolean allowDynamicCode = ____arg2;
//#+
    //$String fileName=$1;
    //$boolean allowDynamicCode=$2;
    if (!allowDynamicCode) {
      return /*$"$1;"$*//*-*/ "";
    }
    else {
      final int index = fileName.lastIndexOf('.');
      final String result;
      if (index < 0) {
        result = "";
      }
      else {
        result = fileName.substring(index + 1);
      }
      return result;
    }
//#-
  }
}
//+
