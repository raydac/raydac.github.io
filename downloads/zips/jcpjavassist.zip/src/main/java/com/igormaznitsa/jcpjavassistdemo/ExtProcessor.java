package com.igormaznitsa.jcpjavassistdemo;

public final class ExtProcessor {
  
  public String extractExtension(final String fileName, final boolean allowDynamicCode) {
    return null;
  }
}
