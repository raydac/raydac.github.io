import java.io.InputStream;

public class main implements RRGGLVMListener
{
    private void printStackState(RRGGLbinVM _vm)
    {
        int i_SPDepth = _vm.getRegisterState(RRGGLbinVM.REGISTER_SP);
        int i_RSDepth = _vm.getRegisterState(RRGGLbinVM.REGISTER_RS);

        int [] ai_sp = _vm.getSPStack();
        int [] ai_rs = _vm.getRSStack();

        int i_maxDepth = Math.max(i_SPDepth,i_RSDepth);

        System.out.println("+-----------------+-----------------+");
        System.out.println("|      SP         |        RS       |");
        System.out.println("+-----------------+-----------------+");

        while(i_maxDepth!=0)
        {
            if (i_SPDepth>0)
            {
                int i_val = ai_sp[i_SPDepth-1];
                String s_str = Integer.toString(i_val);

                s_str = "                 ".substring(s_str.length())+s_str;

                System.out.print("|"+s_str);
                i_SPDepth--;
            }
            else
            {
                System.out.print("|                 ");
            }

            System.out.print("|");

            if (i_RSDepth>0)
            {
                int i_val = ai_rs[i_RSDepth-1];
                String s_str = Integer.toString(i_val);

                s_str = "                 ".substring(s_str.length())+s_str;

                System.out.print(s_str+"|");

                i_RSDepth--;
            }
            else
            {
                System.out.print("                 |");
            }

            i_maxDepth--;

            System.out.println();
        }
        System.out.println("+-----------------+-----------------+");
    }


    public void error(RRGGLbinVM _vm, String _source, int _string, int _position, String _message)
    {
        System.out.println("Error: src="+_source+" string="+_string+" pos="+_position+" msg="+_message);
        System.out.println("Stacks state");
        System.out.println("---------------");
        printStackState(_vm);
    }

    public void processSignal(RRGGLbinVM _vm)
    {
        if (_vm.getRegisterState(RRGGLbinVM.REGISTER_SP)==0)
        {
            System.out.println ("Called SIGNAL for empty SP stack");
        }
        else
        {
            int i_sp = _vm.popSP();
            switch(i_sp)
            {
                case 0 : // ����� "N."
                {
                    System.out.println("SP TOP: "+_vm.popSP());
                };break;
                case 1 : // ����� "S."
                {
                    System.out.println("SP TOP: "+_vm.getStringForIndex(_vm.popSP()));
                };break;
                default :
                {
                    System.out.println("Called SIGNAL for SP top = "+i_sp);
                }
            }
        }
    }

    public void callObject(RRGGLbinVM _vm)
    {
        System.out.println("Called #");
        System.out.println("Stacks");
        System.out.println("---------------");
        printStackState(_vm);
    }

    public main() throws Throwable
    {
        InputStream p_scriptInputStream = getClass().getResourceAsStream("test.cmp");

        if (p_scriptInputStream == null) throw new Throwable("Sorry but I can not open test.cmp");

        RRGGLbinVM p_vm = new RRGGLbinVM(p_scriptInputStream,this);
        p_vm.resetVM();
        p_vm.executeWord(0,false);
    }

    public static final void main(String [] _args)
    {
        try
        {
            new main();
        }
        catch (Throwable _ex)
        {
            _ex.printStackTrace();
        }
    }
}
