/**
 * The interface enables to implement a listener for a RRGGL VM
 * and process both '#' and 'SIGNAL' words
 *
 * @author Igor Maznitsa (igor.maznitsa@igormaznitsa.com)
 * @version 1.00
 *
 * (C) 2004-2006 Raydac Research Group Ltd. (http://www.coldcore.ru)
 */
public interface RRGGLVMListener
{
    /**
     * Processing of the 'SIGNAL' word
     * @param _vm the pointer to the source VM
     */
    public void processSignal(RRGGLbinVM _vm);

    /**
     * Processing of the '#' word
     * @param _vm the pounter to the source VM
     */
    public void callObject(RRGGLbinVM _vm);

    /**
     * Processsing a runtime error
     * @param _vm the source VM pointer
     * @param _source the source file name where the error has been throwed (if you don't have debug info then the value is undefined)
     * @param _string the string number of sources where the error has been throwed (if you don't have debug info then the value is undefined)
     * @param _position the position number of string where the error has been throwed (if you don't have debug info then the value is undefined)
     * @param _message the exception message
     */
    public void error(RRGGLbinVM _vm,String _source,int _string,int _position,String _message);
}
