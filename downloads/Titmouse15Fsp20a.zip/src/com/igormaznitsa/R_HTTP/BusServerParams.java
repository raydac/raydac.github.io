package com.igormaznitsa.R_HTTP;

import java.util.*;

import com.igormaznitsa.RImage.*;

public class BusServerParams
{

    public Hashtable mtable;
    public Hashtable dbaliases;
    public RImageFont dfont;
    public Hashtable RHTTPServers;

    public String MailServerAddress;
    public int MailServerPort;
    public String BackMailAddress;

    public Hashtable aliases;

    public String ServerVersion = "Titmouse Internet Server";

    public BusServerParams()
    {

    }

}
