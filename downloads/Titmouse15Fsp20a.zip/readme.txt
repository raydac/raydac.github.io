Hello

The package contains the compiled version of the Titmouse intranet server v1.5 with FSP 2.0a support. The server is presented AS IS and I don't have any responsibility for any use of the server. 

Directory Example contains a small example of a FSP use
default.rf - the default font for graphic operations (format of SMAL32)
RHTTP_Server.jar - the jar file contains the compiled java code of the server
Server.ini - the file contains the settings of the server
doc/FSP2.pdf - the file contains the list of FSP words
src - the directory contains all sources of the server

Sorry but a lot of comments in the sources in russian... it is very old project (1999) I didn't know english in that time and (unforyunately) don't know it at present :(  ....... aaaaaa... when will I have learned the language? :( may be I am too stupid for that :(

if you have any question, you can contact me through email igor.maznitsa@igormaznitsa.com or through ICQ 77483939