//#excludeif true
//#-
package test;
//#+
//#prefix+
import java.util.Vector;
//#prefix-

//#define ENABLEOUT

//#-
public class _MainProcedure
{
//#+
 	public static final void main(String [] args)
 	{
 	 	System.out.println(/*$HelloWorld$*/);
 	 	//#if ENABLEOUT
 	 	System.err.println("Error");
 	 	//#endif
 	}
 	
//#-
}
//#+