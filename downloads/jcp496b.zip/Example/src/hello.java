/**
  �������� �����
*/
public class hello
{

	//#local TESTVAR="TEST LOCAL VARIABLE"

	//#assert "TESTVAR="+/*$TESTVAR$*/

	//#include ".//test//_MainProcedure.java"

	// ���� ������� ���� (the string of russian letters)
	
	public static final void testproc()
	{
	 	System.out.println(/*$VARHELLO$*/);
	 	System.out.println("// Hello commentaries");

		//#local counter=10
		//#while counter!=0
		System.out.println("Number /*$counter$*/");
		//#local counter=counter-1
		//#end
		
		System.out.println("Current file name is /*$SRV_CUR_FILE$*/");
	    System.out.println("Output dir is /*$SRV_OUT_DIR$*/");
	    //#if strhas("Hello","Hello world")
	    	System.out.println("Substring found");
	    //#endif
	}
}