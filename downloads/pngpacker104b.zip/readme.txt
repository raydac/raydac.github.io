RRG PNG Packer
v.1.03

(C) 2002-2006 Raydac Research Group Ltd. (http://www.raydac-research.com)

The utilite helps you to pack PNG image from either PNG,JPG,GIF or TGA images (or their list) via either Drag'n'Drop operation (you just should place an image on the ColdCore logo) or command string (to give a file list as arguments).

The utility produce hi-packed PNG file(s) from your source files and process their color palettes for right processing of the images on mobile phones SAMSUNG and LG.

The utility can be used absolutely free but you must not make any changing in the utility and reengineering it.

Version story:

1.04
* The code to check JRE version has been added, it enables start the utility under Java 1.4

1.03
* The first version are placed for public use. GUI works only under Java 1.5 or later