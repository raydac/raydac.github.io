CommentProcessor 4.95b (05 may 2007)

(C) 2002-2007 Igor Maznitsa (http://www.igormaznitsa.com)

------------------------------------------------------------------------------------------------------------
NOTE:
I'd like to tell you SORRY for my English because I have not enough experience in writing on the language (ahh, how it would be good if peoples could speak in Java or C++).
------------------------------------------------------------------------------------------------------------

The preprocessor enables you to process directives in comment blocks of your sources and generate new sources. It was developed because Java doesn't have any legal way to include preprocessor tags.
CommentPreprocessor is a free software and I don't account for using the preprocessor and any consequences.
I'd like to say that the preprocessor can be used not only for sources preprocessing, as an example I assmble the web site (http://www.coldcore.ru) from xml documents and html templates with the preprocessor (of course you can tell me that there are more standart ways for it, but I like to use own technologies because their use is more easy for me)

The schema of working of the preprocessor
===========================================
The preprocessor is a two-pass preprocessor. During the first pass it processes global variables and during the second pass it preprocesses sources.

File list
==============================
iamp.jar - the preprocessor
readme.txt - you are reading this file :)
all other files are used as a test example

Preprocessor directives
==================================
Attention! The preprocessor is case-sensitive. 

com.igormaznitsa.preprocessor.Preprocessor [@file_path] [/F:filter_list] [/N] [/I:in_dir] [/O:out_dir] [/P:name=value]
@file_path      - to download variable list from the file
/N              - the output directory will not be cleared before (default it will be cleared) 
/I:in_dir       - the name of the input directory (default ".\"
/O:out_dir      - the name of the output directory (default "..\preprocessed")
/P:name=value   - the name and the value of a parameter, ATTENTION: If you want set a string value, you must use symbol '$' instead of '"'("Hello"=$Hello$)
/R              - remove all comments from prprocessed sources
/CA             - copy all files, processing only files in the extension list
/F:filter_list  - set the extensions for preprocessed files (default /F:java,txt,html,htm)
/EF:filter_list - set the extensions for excluded files (default /EF:xml)

Preprocessor directives
-------------------------------------------------
//#action EXPR0,EXPR1...EXPRn   To generate an action for an outside preprocessor action listener
//#global NAME=EXPR             To define a global variable
//#local  NAME=EXPR             To define a local variable
//#define NAME                  To define a local logical variable as TRUE (you can use it instead of //#local NAME=true)
//#if BOOLEAN_EXPR              The beginning of a #if..#else..#endif block
//#ifdefined VARIABLE_NAME      The beginning of a #ifdefined..#else..#endif block, TRUE if the variable is exists else FALSE
//#else                         To change the flag for current #if construction
//#endif                        To end current #if construction
//#include STRING_EXPR          Include a file from the path which has been gotten from the expression
//#excludeif BOOLEAN_EXPR       Exclude a file from the preprocessor output list if the expression is true
//#exit                         Abort current file preprocessing
//#exitif BOOLEAN_EXPR          Abort current file preprocessing if the expression is true
//#while BOOLEAN_EXPR           Start of //#while..//#end construction
//#break                        To break //#while..//#end construction
//#continue                     To continue //#while..//#end construction
//#end                          End of //#while..//#end construction
//#//                           Comment the next string with "//" in the output stream
/*-*/                           Give up the tail of the string after the command
/*$EXPR$*/                      Insert the string view of the expression into the output stream
//#-                            Turn off the flag of string outputting
//#+                            Turn on the flag of string outputting
//$                             Output the tail of the string into the output stream without comments
//$$                            Output the tail of the string into the output stream without comments and without processing of /*$..$*/
//#assert                       Output the tail of the string onto the console
//#prefix+                      All strings after the directive will be added in the beginning of generated file
//#prefix-                      Turn off the prefix mode
//#postfix+                     All strings after the directive will be added in the end of generated file
//#postfix-                     Turn off the postfix mode
//#outdir  STRING_EXPR          The destination dir for the file
//#outname  STRING_EXPR         The destination name for the file
//#flush                        To write current text buffer states into the destination file and to clear them.
//#_if BOOLEAN_EXPR             The beginning of a #_if..#_else..#_endif block (works during finding of global variables at sources)
//#_else                        Change the flag for current #_if construction
//#_endif                       To end current #_if construction
-------------------------------------------------
Expression operators:

Arithmetic : *,/,+,%
Logical    : &&,||,!,^ (&&-AND,||-OR,!-NOT,^-XOR)
Comparison : ==,!=,<,>,>=,<=
Brakes     : (,)
-------------------------------------------------
Functions:

FLOAT|INTEGER   abs(FLOAT|INTEGER)              Return the absolute value of an int or float value.
INTEGER         round(FLOAT|INTEGER)            Return the closest int to the argument.
STRING          str2web(STRING)                 Convert a string to a web compatible string.
INTEGER         strlen(STRING)                  Return the length of a string
INTEGER         str2int(STRING)                 Convert a string value to integer
INTEGER xml_open(STRING)                        Open an xml document for the name as the argument, return the ID of the document
INTEGER xml_getDocumentElement(INTEGER)         Return the document element for an opened xml document
INTEGER xml_getElementsForName(INTEGER,STRING)  Return an elemens list
INTEGER xml_elementsNumber(INTEGER)             Return number of elements in the list
INTEGER xml_elementAt(INTEGER)                  Return element for index in the list
STRING  xml_elementName(INTEGER)                Return the name of element
INTEGER xml_getAttribute(INTEGER,STRING)        Return attribute value of an element
INTEGER xml_getElementText(STRING)              Return text value of an element
VALUE   $user_name(EXPR0,EXPR1..EXPRn)          User defined function, it returns variable (undefined type)
-------------------------------------------------
Data types:

BOOLEAN: true,false
INTEGER: 2374,0x56FE (signed 64 bit)
STRING : "Hello World!" (or $Hello World!$ as a variant to be given via command string)
FLOAT  : 0.745 (signed 32 bit)
-------------------------------------------------
ANT task class is jcpreprocessor.ant.JCPreprocessor and it has listed attributes:
outdir="String" = /O: (default ../preprocessed)
indir="String"  = /I: (default ./)
filter="String" = /F: (default java,txt,html,htm)
excfilter="String" = /EF: (default xml)
copyall="String" = /CA (default false)
clearout="boolean" = /N (default true)
removecomments="boolean" = /R (default false)
arguments="String" = it is a path to a fil contains an argument string

You can add a global variable with "<global name="<NAME>" value="<VALUE>"/>" inside the ANT command.
So you can use ANT properties from the preprocessor as renamed global variables as example "build.root.dir = ANT_build_root_dir"
You should add in your ANT script the string "<taskdef resource="jcpreprocessor/ant/task.properties" classpath="<JavaCommentPreprocessor>.jar"/>" to use the preprocessor from the script.


Version history
==================================
v.4.95b
*Ant support added
*minor bugs fixed

v.4.91b (there were a lot of intermediate versions and I could forget some things or fixing)
*Fixed a lot of major bugs
*Integer type has become 64 bit
*Added //#_if //#_else //#_endif for conditional processing of global variables
*Added //#define VAR that replacing //#local VAR=true
*Added commands for working with XML documents
*Added commands for working with cycles
*Added support of user defined functions

v.3.00b
*Bugfixing
*The "//$$" directive has been added.
*The "//#action" directive has been added.
*ABS and ROUND functions have been added.

v2.95b
*The /R option removes comments from preprocessed sources

v2.91b
*The problem of processing non-english chars has beed removed

v2.9b
*The format of /F: parameter has been changed, I have changed the delimeter from "|" to ","
*I've added the @ argumet what enables to download a variable list from a file.
*The "//#ifdefine" directive has been added. The directive enables you to check the existence of a variable.

v2.7b
*The /N command option has been added. The option enables you to hold the output directory has not been cleared before preprocessing. But remember please, what in the case your output directory must not be placed in the input directory else you will get very strange results of the preprocessing :).

v2.6b
*A few bugs have been removed.
*The "//#outpath" command has been added.

v2.3b
*A few new derictives have been added "//#prefix+", "//#prefix-", "//#postfix+", "//#postfix-"

v2.2b

*The preprocessed document formatting info is saved
*The /F:filters command option has been added
*The "//#assert" directive has been added
*The bug of "//#//" processing has been removed.

v2.1b
*Diagnostical messages were not shown onto the consol.
*There was the error when an user wanted to set any string value with the command string.

v2.0b 
The first published version


Copyright ɠ2003-2006 Igor A. Maznitsa. All Rights Reserved.
Send comments and questions to {igor.maznitsa@igormaznitsa.com}.
