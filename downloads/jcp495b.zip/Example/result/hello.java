import java.util.Vector;
public class hello
{





  public static final void main(String [] args)
  {
    System.out.println("TEST LOCAL VARIABLE");
    System.out.println("Hi");
    System.err.println("Error");
  }



 public static final void testproc()
 {
   System.out.println("Hello world");
   System.out.println("// Hello commentaries");

  System.out.println("Number 10");
  System.out.println("Number 9");
  System.out.println("Number 8");
  System.out.println("Number 7");
  System.out.println("Number 6");
  System.out.println("Number 5");
  System.out.println("Number 4");
  System.out.println("Number 3");
  System.out.println("Number 2");
  System.out.println("Number 1");
 }
}
