CommentProcessor 2.9b

The preprocessor enables you to process directives in comment blocks of your sources and generate new sources. It was developed because Java doesn't have any legal way to include preprocessor tags.
CommentPreprocessor is a free software and I don't account for using the preprocessor and any consequences.

File list
==============================
iamp.jar - the preprocessor
readme.txt - you are reading this file :)
all other files are used as a test example

Preprocessor directives
==================================
Attention! The preprocessor is case-sensitive. 

//#global NAME=EXPR         to define a global variable
the preprocessor is double-pass, during the first pass it finds global variables , you must not duplicate their names

//#local  NAME=EXPR         to define a local variable
a local variable with the name is visible in the source where it has been defined only, you can give to a local variable the name of a global variable and the local variable will replace the global variable in the source.

//#ifdefine VARIABLE_NAME   The beginning of a #ifdefine..#else..#endif block, TRUE if the variable is exists else FALSE

//#if BOOLEAN_EXPR          To begin a #if..#else..#endif block
//#else                     Change the flag for current #if construction
//#endif                    End current #if construction

//#include STRING_EXPR      Include the file with the path from the expression

//#excludeif BOOLEAN_EXPR   Exclude the file from the preprocessor output list if the expression is true, but all variables from the file will be shared.
//#break                    Abort preprocessing current file
//#breakif BOOLEAN_EXPR     Abort preprocessing current file if the expression is true
//#//                       Comment next string with "\\" in the output stream
/*-*/                       Give up the tail of the string after the command
/*$EXPR$*/                  Insert the string view of the expression into the output stream
//#-                        Turn off the flag of string output to the out stream
//#+                        Turn on the flag of string output to the out stream
//$                         Output the tail of the string into the output stream without comments
//#assert					Output the tail of the string into the output info stream
//#prefix+	All strings after the directive will be added in the beginning of generated file
//#prefix-					Turn off the prefix mode
//#postfix+					All strings after the directive will be added in the end of generated file
//#postfix-					Turn off the postfix mode
//#outpath STR_EXPR			To change the output path for the preprocessed file to the path from the expression

Expression operators:
==================================
Arithmetic : *,/,+,%
Logical    : &&,||,!,^
Comparation: ==,!=,<,>,>=,<=
Brakes     : (,)

Data types:

BOOLEAN: true,false
INTEGER: 2374,0x56FE
STRING : "Hello World!"
FLOAT  : 0.745

Command line
==================================
com.igormaznitsa.Preprocessor.Preprocessor [@file_path] [/N] [/F:file_ext_lst] [/I:in_dir] [/O:out_dir] [/P:name=value]
@file_path      - to download variable list from the file, you must not use the $ symbol instead of " in the declarations of variables in the file. In a variable list file you can use below declarations:
	VARIABLENAME=@STRING_EXPRESSION (as an example VAR1=@"file.txt")
	where STRING_EXPRESSION is the name of a file what will be used as the container for value of the variable. Note: all strings of the file what contain /*$...$*/ will be prepared. In a variable list file you can use empty strings (they will nod be processed) and the symbol "#" as the sign of a comments (the string will not be processed too)

/I:in_dir       - name of the input directory (default ".\")
/O:out_dir      - name of the output directory (default "..\preprocessed")
/P:name=value   - name and value of a parameter, there can be a few parameters in the string, if you want to set any string value you must use the '$' symbol instead of '"'
/R              - remove all comments from preprocessed sources
/F:file_ext_lst - the list of processed file extensions, the default value "java,txt" (/F:java,txt)


Version history
==================================
v2.95b
*The /R option removes comments from preprocessed sources

v2.91b
*The problem of processing non-english chars has beed removed

v2.9b
*The format of /F: parameter has been changed, I have changed the delimeter from "|" to ","
*I've added the @ argumet what enables to download a variable list from a file.
*The "//#ifdefine" directive has been added. The directive enables you to check the existence of a variable.

v2.7b
*The /N command option has been added. The option enables you to hold the output directory has not been cleared before preprocessing. But remember please, what in the case your output directory must not be placed in the input directory else you will get very strange results of the preprocessing :).

v2.6b
*A few bugs have been removed.
*The "//#outpath" command has been added.

v2.3b
*A few new derictives have been added "//#prefix+", "//#prefix-", "//#postfix+", "//#postfix-"

v2.2b

*The preprocessed document formatting info is saved
*The /F:filters command option has been added
*The "//#assert" directive has been added
*The bug of "//#//" processing has been removed.

v2.1b
*Diagnostical messages were not shown onto the consol.
*There was the error when an user wanted to set any string value with the command string.

v2.0b 
The first published version

Copyright © 2003 Igor A. Maznitsa. All Rights Reserved.
Send comments and questions to {igor.maznitsa@igormaznitsa.com}.
