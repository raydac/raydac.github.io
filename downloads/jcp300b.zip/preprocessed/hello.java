import java.util.Vector;
public class hello
{

 	public static final void main(String [] args)
 	{
 	 	System.out.println("Hi");
 	}


	public static final void testproc()
	{
	 	System.out.println("Hello world");
	 	System.out.println("// Hello commentaries");
	}
}
