//#excludeif true
//#-
package test;
//#+
//#prefix+
import java.util.Vector;
//#prefix-

//#-
public class _MainProcedure
{
//#+
 	public static final void main(String [] args)
 	{
 	 	System.out.println(/*$HelloWorld$*/);
 	}
//#-
}
//#+