TV Viewer

(C) 2006 Raydac Research Grop Ltd. http://www.coldcore.ru
Author: Igor Maznitsa (http://www.igormaznitsa.com)

The utility enables you to check your image for NTSC TV screen compatibility. You can check both color problems and area problems. So the utility can process you image and save the result on a disk as a PNG image. The utility distributed under the BSD license (you can find the license in the utility archive).

The utility written with Java2 SE and you need have installed JRE or JDK 1.5 or later. It can be started with start.bat script or via command string:

java.exe -jar tvviewer.jar

Version history:

1.0.2
* Animated picture has been added

1.0.1
* Corrected major color bugs 
* More correct NTSC emulation

1.0
* Placed in the net
