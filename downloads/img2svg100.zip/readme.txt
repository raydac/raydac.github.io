IMG2SVG

Author: Igor Maznitsa (http://www.igormaznitsa.com)
Version: 1.00
----
!!!! The utility needs installed Java SE 1.6 JRE 1.6 or later, it can be download from the http://java.sun.com page
----
The IMG2SVG utility is a very easy converter allows to convert a raster image into its SVG representation. Of course it doesn't convert raster in vector but it just make the SVG shell around the packed raster image data. Also the utility allows make a mask image where the opaque pixels shown as black ones and transparent pixels shown as white ones, it very useful to make icons for Nokia Series 60 (the utility was developed by me for the case).

The utility and its sources are absolutely free and you can use and edit them for your needs. The utility was developed under NetBeans IDE 6.8.

To start the utility under Windows, use the start.bat script and to to start the utility nder Linux, use the start.sh script.