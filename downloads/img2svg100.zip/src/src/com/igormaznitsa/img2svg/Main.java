package com.igormaznitsa.img2svg;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Iterator;
import java.util.LinkedList;
import javax.imageio.ImageIO;
import javax.swing.SwingUtilities;

public class Main {

    public static final String CAPTION = "IMG2SVG Utility";
    public static final String VERSION = "v1.00";
    public static final String AUTHOR = "Igor A. Maznitsa (http://www.igormaznitsa.com)";
    public static final String SHORTREFERENCE = "The utility allows to convert an image represented as a raster image (in the GIF, PNG or JPG format) into the SVG format. Of course the utility too poor to convert raster to vector but it make a SVG shell for the image.";
    public static final String COMMANDLINE = "java -jar img2svg.jar [mask:yes] [type:[jpg|gif|png]] <input_file_name> [output_file_name]";

    public static final void main(String[] args) {
        System.out.println(CAPTION + " " + VERSION + "\r\n" + AUTHOR + "\r\n-------------------------------");

        if (args.length == 0) {
            SwingUtilities.invokeLater(new Runnable() {

                public void run() {
                    new MainFrame().setVisible(true);
                }
            });

        } else {

            Img2SvgConverter.ImageType embeddedtype = Img2SvgConverter.ImageType.PNG;

            boolean makeMask = false;

            LinkedList<String> strList = new LinkedList<String>();
            for (String str : args) {
                strList.add(str);
            }

            Iterator<String> iter = strList.iterator();

            while (iter.hasNext()) {
                String arg = iter.next().toLowerCase();

                if (arg.startsWith("type:")) {
                    arg = arg.substring(5).trim();

                    if (arg.equals("jpg")) {
                        embeddedtype = Img2SvgConverter.ImageType.JPG;
                    } else if (arg.equals("png")) {
                        embeddedtype = Img2SvgConverter.ImageType.PNG;
                    } else if (arg.equals("gif")) {
                        embeddedtype = Img2SvgConverter.ImageType.GIF;
                    } else {
                        System.err.println("An unsupported embedded image type has been found [" + arg + "], you may use only JPG, PNG or GIF.");
                        System.exit(0);
                    }

                    // remove the argiument
                    iter.remove();
                    args = strList.toArray(new String[strList.size()]);
                } else if (arg.startsWith("mask:")) {
                    arg = arg.substring(5).trim();
                    makeMask = arg.equals("yes");
                    iter.remove();
                }
            }

            args = strList.toArray(new String[strList.size()]);

            if (args.length > 0) {
                String infile = args[0];
                String outfile = infile + ".svg";
                String outfilemask = infile + "_mask.svg";

                if (args.length > 1) {
                    outfile = args[1];
                }

                File inFile = null;
                FileOutputStream outStream = null;

                try {
                    inFile = new File(infile);
                    File outFile = new File(outfile);

                    System.out.println("Loading image " + inFile.getAbsolutePath());
                    BufferedImage image = ImageIO.read(inFile);

                    Img2SvgConverter converter = new Img2SvgConverter(image, embeddedtype);
                    System.out.println("Saver result SVG as " + outFile.getAbsolutePath());
                    outStream = new FileOutputStream(outFile);
                    PrintStream filePrintStream = new PrintStream(outStream);
                    converter.print(filePrintStream);
                    filePrintStream.flush();

                    if (makeMask) {
                        outStream.close();

                        outFile = new File(outfilemask);
                        BufferedImage img = converter.makeMask();
                        converter = new Img2SvgConverter(img, embeddedtype);
                        System.out.println("Save the image mask as SVG file " + outFile.getAbsolutePath());

                        outStream = new FileOutputStream(outFile);

                        filePrintStream = new PrintStream(outStream);
                        converter.print(filePrintStream);
                        filePrintStream.flush();
                    }

                } catch (Exception ex) {

                    System.out.println(SHORTREFERENCE + "\r\n");
                    System.out.println(COMMANDLINE);
                    System.exit(0);

                    ex.printStackTrace();
                    System.exit(0);
                } finally {
                    if (outStream != null) {
                        try {
                            outStream.close();
                        } catch (Throwable thr) {
                            thr.printStackTrace();
                        }
                    }
                }
            } else {
                System.out.println(SHORTREFERENCE + "\r\n");
                System.out.println(COMMANDLINE);
                System.exit(0);
            }
        }
    }
}
