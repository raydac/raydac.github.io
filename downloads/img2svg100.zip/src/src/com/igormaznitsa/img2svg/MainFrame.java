package com.igormaznitsa.img2svg;

import com.igormaznitsa.img2svg.Img2SvgConverter.ImageType;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.AbstractCellEditor;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableModel;

/**
 * The class implements the GUI for IMG2SVG utility
 * It was written very quickly and no so optimally
 * @author Igor Maznitsa (http://www.igormaznitsa.com)
 * @version 1.00
 */
public class MainFrame extends javax.swing.JFrame implements TableModel, ListSelectionListener {

    private File lastOpenedFile = null;
    private static final FileFilter ImageFileFilter = new FileFilter() {

        @Override
        public boolean accept(File f) {
            if (f == null) {
                return false;
            }
            if (f.isDirectory()) {
                return true;
            }

            String name = f.getName().toLowerCase();
            return name.endsWith(".gif") || name.endsWith(".jpg") || name.endsWith(".png");
        }

        @Override
        public String getDescription() {
            return "Images (*.gif, *.jpg, *.png)";
        }
    };

    public static class ImageTypeEditor extends AbstractCellEditor implements TableCellEditor, ActionListener {

        public JComboBox boxEditor;

        public ImageTypeEditor() {
            boxEditor = new JComboBox();
            boxEditor.removeAllItems();
            boxEditor.addItem(Img2SvgConverter.ImageType.GIF);
            boxEditor.addItem(Img2SvgConverter.ImageType.JPG);
            boxEditor.addItem(Img2SvgConverter.ImageType.PNG);

            boxEditor.addActionListener(this);
        }

        public Object getCellEditorValue() {
            return boxEditor.getSelectedItem();
        }

        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            boxEditor.setSelectedItem(value);
            return boxEditor;
        }

        public void actionPerformed(ActionEvent e) {
            fireEditingStopped();
        }
    }

    static final class ImageInfo {

        private File SrcFile;
        private String DstFileName;
        private Img2SvgConverter.ImageType Type;
        private boolean MakeMask;
        private final BufferedImage LoadedImage;

        public ImageInfo(final File file, final Img2SvgConverter.ImageType type, final boolean makeMask) throws IOException {
            MakeMask = makeMask;
            SrcFile = file;
            Type = type;
            DstFileName = file.getName() + ".svg";

            LoadedImage = ImageIO.read(SrcFile);
        }

        private int showOverrideDialog(final JFrame owner,final  File file) {
            if (file.exists()) {
                return JOptionPane.showConfirmDialog(owner, "File \'" + file.getAbsolutePath() + "\' already exists. Do you want to overwrite it?", "Overwrite file?",JOptionPane.YES_NO_CANCEL_OPTION);
            } else {
                return JOptionPane.YES_OPTION;
            }
        }

        /**
         * Make SVG file and mask from the current image saved in the object
         * @param owner the component to be used as owner for dialogs
         * @return return false if we can continue other operations, if true we need disable all other operations
         */
        public boolean convert(final JFrame owner) {
            Img2SvgConverter converter = new Img2SvgConverter(LoadedImage, Type);

            // save file
            File file = new File(SrcFile.getParent(), DstFileName);
            FileOutputStream writer = null;

            switch (showOverrideDialog(owner, file)) {
                case JOptionPane.YES_OPTION: {
                    try {
                        writer = new FileOutputStream(file);
                        PrintStream out = new PrintStream(writer);
                        converter.print(out);
                        out.flush();
                        out.close();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(owner, "I can't save the image file \"" + file.getAbsolutePath() + "\" [" + ex.getMessage() + "]","Can't save an image file",JOptionPane.ERROR_MESSAGE);
                        return true;
                    } finally {
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                    }
                }
                break;
                case JOptionPane.CANCEL_OPTION:
                    return true;
                default:
                    return false;
            }

            if (MakeMask) {
                file = new File(SrcFile.getParent(), DstFileName + "_mask.svg");
                switch (showOverrideDialog(owner, file)) {
                    case JOptionPane.YES_OPTION: {
                        try {
                            Img2SvgConverter mask = new Img2SvgConverter(converter.makeMask(),ImageType.PNG);

                            writer = new FileOutputStream(file);
                            PrintStream out = new PrintStream(writer);
                            mask.print(out);
                            out.flush();
                            out.close();
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            JOptionPane.showMessageDialog(owner, "I can't save the mask image file \"" + file.getAbsolutePath() + "\" [" + ex.getMessage() + "]","Can't save a mask file",JOptionPane.ERROR_MESSAGE);
                            return true;
                        } finally {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                }
                            }
                        }
                    }
                    break;
                    case JOptionPane.CANCEL_OPTION:
                        return true;
                    default:
                        return false;
                }
            }

            return false;
        }
    }
    private final ArrayList<ImageInfo> imageConversionList;
    private ArrayList<TableModelListener> tableListeners = new ArrayList<TableModelListener>();

    /** Creates new form MainFrame */
    public MainFrame() {
        initComponents();

        setTitle(Main.CAPTION+" "+Main.VERSION);

        try {
            setIconImage(new ImageIcon(this.getClass().getResource("/com/igormaznitsa/img2svg/img2svg_logo.png")).getImage());
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }

        imageConversionList = new ArrayList<ImageInfo>();

        ImageListTable.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        ImageListTable.getSelectionModel().addListSelectionListener(this);
        ImageListTable.setModel(this);
        ImageListTable.getColumnModel().getColumn(3).setCellEditor(new ImageTypeEditor());
    }

    public void valueChanged(ListSelectionEvent e) {
        int index = ImageListTable.getSelectedRow();
        if (index < 0) {
            ButtonRemoveImage.setEnabled(false);
            PreviewPanel.removeAll();
            PreviewPanel.revalidate();
            PreviewPanel.repaint();

            return;
        } else {
            ImageInfo info = imageConversionList.get(index);
            Dimension previewSize = PreviewPanel.getSize();

            Image img = info.LoadedImage.getScaledInstance((previewSize.width * 2) / 3, (previewSize.height * 2) / 3, Image.SCALE_SMOOTH);

            PreviewPanel.removeAll();
            PreviewPanel.add(new JLabel(new ImageIcon(img)), BorderLayout.CENTER);
            PreviewPanel.revalidate();
            PreviewPanel.repaint();

            ButtonRemoveImage.setEnabled(true);
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ButtonConvert = new javax.swing.JButton();
        ButtonExit = new javax.swing.JButton();
        ListTable = new javax.swing.JScrollPane();
        ImageListTable = new javax.swing.JTable();
        ButtonAddImage = new javax.swing.JButton();
        ButtonRemoveImage = new javax.swing.JButton();
        PreviewPanel = new javax.swing.JPanel();
        ButtonAbout = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);

        ButtonConvert.setText("Convert");
        ButtonConvert.setToolTipText("To convert all images from the list");
        ButtonConvert.setEnabled(false);
        ButtonConvert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonConvertActionPerformed(evt);
            }
        });

        ButtonExit.setText("Exit");
        ButtonExit.setToolTipText("Close the utility");
        ButtonExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonExitActionPerformed(evt);
            }
        });

        ListTable.setBorder(javax.swing.BorderFactory.createTitledBorder("Image list"));

        ImageListTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        ImageListTable.setToolTipText("The image list to be converted into SVG");
        ListTable.setViewportView(ImageListTable);

        ButtonAddImage.setText("Add image");
        ButtonAddImage.setToolTipText("Add new image file into the list");
        ButtonAddImage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonAddImageActionPerformed(evt);
            }
        });

        ButtonRemoveImage.setText("Remove image");
        ButtonRemoveImage.setToolTipText("Remove the selected image from the list");
        ButtonRemoveImage.setEnabled(false);
        ButtonRemoveImage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonRemoveImageActionPerformed(evt);
            }
        });

        PreviewPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Preview"));
        PreviewPanel.setToolTipText("Current selected image");
        PreviewPanel.setLayout(new java.awt.BorderLayout());

        ButtonAbout.setText("About");
        ButtonAbout.setToolTipText("About the utility");
        ButtonAbout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonAboutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(ListTable, javax.swing.GroupLayout.DEFAULT_SIZE, 329, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(PreviewPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 128, Short.MAX_VALUE)
                            .addComponent(ButtonRemoveImage, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ButtonAddImage, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 128, Short.MAX_VALUE)
                            .addComponent(ButtonAbout, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(ButtonConvert, javax.swing.GroupLayout.DEFAULT_SIZE, 463, Short.MAX_VALUE)
                    .addComponent(ButtonExit, javax.swing.GroupLayout.DEFAULT_SIZE, 463, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ButtonConvert)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(ButtonAddImage)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ButtonRemoveImage)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 73, Short.MAX_VALUE)
                        .addComponent(PreviewPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ButtonAbout))
                    .addComponent(ListTable, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ButtonExit)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ButtonExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonExitActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_ButtonExitActionPerformed

    private void ButtonAddImageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonAddImageActionPerformed
        // TODO add your handling code here:
        try {
        JFileChooser fileChooser = new JFileChooser(lastOpenedFile);

        fileChooser.setDialogTitle("Select an image file to be converted into SVG format");
        fileChooser.setFileFilter(ImageFileFilter);
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            lastOpenedFile = file;

            if (!file.exists() || file.isDirectory()) {
                JOptionPane.showMessageDialog(this, "I can't find file named \'" + file.getAbsolutePath() + "\'", "Error file", JOptionPane.ERROR_MESSAGE);
                return;
            }

            ImageType type = ImageType.PNG;

            final String name = file.getName().trim().toLowerCase();
            if (name.endsWith(".gif")) {
                type = ImageType.GIF;
            } else if (name.endsWith(".jpg")) {
                type = ImageType.JPG;
            } else if (name.endsWith(".png")) {
                type = ImageType.PNG;
            }

            try {
                imageConversionList.add(new ImageInfo(file, type, false));
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "I can't load and add the file at the list, may be the file has wrong or unsupported format!", "Error image loading", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
        }
        finally {
            ButtonConvert.setEnabled(imageConversionList.size()>0);
            fireTableUpdate();
        }
    }//GEN-LAST:event_ButtonAddImageActionPerformed

    private void ButtonRemoveImageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonRemoveImageActionPerformed
        // TODO add your handling code here:
        try {
        int selectedRow = ImageListTable.getSelectedRow();
        if (selectedRow<0) return;

        imageConversionList.remove(selectedRow);
        }
        finally {
            fireTableUpdate();
            ButtonConvert.setEnabled(imageConversionList.size()>0);
        }
    }//GEN-LAST:event_ButtonRemoveImageActionPerformed

    private void ButtonAboutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonAboutActionPerformed
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(this, Main.CAPTION+" "+Main.VERSION+"\r\n--------------------------------\r\nAuthor: "+Main.AUTHOR, "About", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_ButtonAboutActionPerformed

    private void ButtonConvertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonConvertActionPerformed
        // TODO add your handling code here:
        if (imageConversionList.size()>0) {
            boolean allOk = true;
            for(ImageInfo info : imageConversionList) {
                if (info.convert(this))
                {
                    allOk = false;
                    break;
                }
            }

            if (allOk) JOptionPane.showMessageDialog(this,"All images have been converted successfuly.", "Completed",JOptionPane.INFORMATION_MESSAGE );
        }
    }//GEN-LAST:event_ButtonConvertActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonAbout;
    private javax.swing.JButton ButtonAddImage;
    private javax.swing.JButton ButtonConvert;
    private javax.swing.JButton ButtonExit;
    private javax.swing.JButton ButtonRemoveImage;
    private javax.swing.JTable ImageListTable;
    private javax.swing.JScrollPane ListTable;
    private javax.swing.JPanel PreviewPanel;
    // End of variables declaration//GEN-END:variables

    public int getRowCount() {
        return imageConversionList.size();
    }

    public int getColumnCount() {
        return 4;
    }

    public String getColumnName(int columnIndex) {
        switch (columnIndex) {
            case 0:
                return "Make mask";
            case 1:
                return "Src.file";
            case 2:
                return "Dst.file";
            case 3:
                return "Pack as";
            default:
                return null;
        }
    }

    public Class<?> getColumnClass(int columnIndex) {
        switch (columnIndex) {
            case 0:
                return Boolean.class;
            case 1:
            case 2:
                return String.class;
            case 3:
                return ImageType.class;
            default:
                return null;
        }
    }

    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return (columnIndex != 1);
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        ImageInfo info = imageConversionList.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return info.MakeMask;
            case 1:
                return info.SrcFile.getAbsoluteFile();
            case 2:
                return info.DstFileName;
            case 3:
                return info.Type;
            default:
                return null;
        }
    }

    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        ImageInfo info = imageConversionList.get(rowIndex);
        switch (columnIndex) {
            case 0:
                info.MakeMask = (Boolean) aValue;
                break;
            case 2:
                info.DstFileName = ((String) aValue).trim();
                break;
            case 3:
                info.Type = (ImageType) aValue;
                break;
        }
    }

    public void fireTableUpdate() {
        for (TableModelListener l : tableListeners) {
            l.tableChanged(new TableModelEvent(this));
        }
    }

    public void addTableModelListener(TableModelListener l) {
        tableListeners.add(l);
    }

    public void removeTableModelListener(TableModelListener l) {
        tableListeners.remove(l);
    }
}
