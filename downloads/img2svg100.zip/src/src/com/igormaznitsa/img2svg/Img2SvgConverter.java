package com.igormaznitsa.img2svg;

import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import javax.imageio.ImageIO;
import sun.misc.BASE64Encoder;

/**
 * The class allows to make SVG shell for a raster image
 * @author Igor Maznitsa (http://www.igormaznitsa.com)
 * @version 1.00
 */
public final class Img2SvgConverter {
    public enum ImageType {
        JPG,PNG,GIF
    }

    private ImageType type;
    private BufferedImage image;

    public Img2SvgConverter(final BufferedImage image, final ImageType type) {
        this.type = type;
        this.image = image;
    }

    public final BufferedImage makeMask() {
        BufferedImage img = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_ARGB);
        img.getGraphics().drawImage(image, 0, 0, null);

        DataBufferInt imgData = (DataBufferInt) img.getRaster().getDataBuffer();

        int [] array = imgData.getData();
        for(int li=0;li<array.length;li++) {
            if ((array[li]& 0xFF000000)==0) {
                array[li] = 0xFFFFFFFF;
            }
            else {
                final int mask =  0xFF-((array[li] >>> 24) & 0xFF);
                array[li] = 0xFF000000 | (mask<<16) | (mask<<8) | mask;
            }
        }

        return img;
    }

    public void print(PrintStream stream) throws IOException {
        String filtername = null;
        String mime = null;

        if (type == ImageType.JPG) {
            mime = "image/jpg";
            filtername = "jpg";
        }
        else
        if (type == ImageType.PNG) {
            mime = "image/png";
            filtername = "png";
        }
        else
        if (type == ImageType.GIF) {
            mime = "image/gif";
            filtername = "gif";
        }


        final int width = image.getWidth();
        final int height = image.getHeight();

        ByteArrayOutputStream baos = new ByteArrayOutputStream(1024);

        ImageIO.write(image, filtername, baos);

        stream.println("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>");
        stream.println("<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 20000303 Stylable//EN\"   \"http://www.w3.org/TR/2000/03/WD-SVG-20000303/DTD/svg-20000303-stylable.dtd\" [<!ENTITY st0 \"fill-rule:nonzero;clip-rule:nonzero;stroke:#000000;stroke-miterlimit:4;\">]>");
        stream.println("<svg  width=\""+width+"\" height=\""+height+"\" viewBox=\"0 0 "+width+" "+height+"\" xml:space=\"preserve\">");
        stream.println("<g id=\"Ebene_x0020_1\" style=\"&st0;\">");

        BASE64Encoder enc = new BASE64Encoder();
        String mimeImage = enc.encode(baos.toByteArray());

        stream.print("<image width=\""+width+"\" height=\""+height+"\" xlink:href=\"data:"+mime+";base64,");
        stream.print(mimeImage);
        stream.println("\" transform=\"matrix(1 0 0 1 0 0)\"/>");
        stream.println("</g>");
        stream.println("</svg>");
    }

}
