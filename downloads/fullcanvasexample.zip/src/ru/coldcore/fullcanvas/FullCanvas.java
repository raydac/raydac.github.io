package ru.coldcore.fullcanvas;

import javax.microedition.lcdui.Graphics;

/**
 * The class extends a MIDP Canvas, but be careful it need the Canvas class contains setFullScreen(boolean _flag) function for its compilation
 * @author Igor Maznitsa (igor.maznitsa@igormaznitsa.com)
 * @version 1.00
 */
public class FullCanvas extends javax.microedition.lcdui.Canvas
{
    /**
     * The variable contains the width of the canvas
     */
    public int i_screenWidth;

    /**
     * The variable contains the height of the canvas
     */
    public int i_screenHeight;

    /**
     * The variable contains a flag of MIDP 2.0 possibilities of the middleware
     */
    private boolean lg_CreatedUnderMIDP20;

    /**
     * The variable contains a flag that can be useful for us to know that the first repaint after displaying is presented
     */
    private static boolean lg_firstPaint = true;

    public void showNotify()
    {
        lg_firstPaint = true;
        repaint();
    }

    public void hideNotify()
    {
    }

    public FullCanvas()
    {
        super();

        try
        {
            // We need to check MIDP2.0 possibility
            Class.forName("javax.microedition.lcdui.Spacer");
            lg_CreatedUnderMIDP20 = true;
        }
        catch (Throwable e)
        {
            lg_CreatedUnderMIDP20 = false;
        }

        if (lg_CreatedUnderMIDP20)
        {
            // the canvas has been created under MIDP 2.0 thus we can use the function below
            setFullScreenMode(true);
        }

        // We need to get the size of the canvas and place it in the inside variables
        i_screenWidth = super.getWidth();
        i_screenHeight = super.getHeight();
    }

    /**
     * A constructor. We need to add the constructor to use it under NokiaCanvas
     * @param _width a size of the canvas
     * @param _height a height of the canvas
     */
    public FullCanvas(int _width,int _height)
    {
        super();

        i_screenWidth = _width;
        i_screenHeight = _height;

    }

    /**
     * We need to override the getWidth() function of the base class to return our width value
     * @return the width value
     */
    public int getWidth()
    {
        return i_screenWidth;
    }

    /**
     * We need to override the getHeight() function of the base class to return our height value
     * @return the height value
     */
    public int getHeight()
    {
        return i_screenHeight;
    }

    public void paint(Graphics _graphics)
    {
        if (lg_firstPaint)
            _graphics.setClip(0, 0, i_screenWidth, i_screenHeight);

        _graphics.setColor(0);

        String s_Str = "CANVAS "+(lg_CreatedUnderMIDP20 ? "2.0" : "1.0");

        _graphics.drawString(s_Str,1,i_screenHeight-1,Graphics.BOTTOM|Graphics.LEFT);
        _graphics.setColor(0xFFFFFF);
        _graphics.drawString(s_Str,0,i_screenHeight-1,Graphics.BOTTOM|Graphics.LEFT);
    }


    protected void keyPressed(int _key)
    {

    }

    protected void keyReleased(int _key)
    {

    }
}
