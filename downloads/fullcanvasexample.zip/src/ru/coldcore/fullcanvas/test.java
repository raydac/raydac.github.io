package ru.coldcore.fullcanvas;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Canvas;

/**
 * It is a test midlet that shows the possibility to use a full screen under different device dependent API
 * @author Igor Maznitsa (igor.maznitsa@igormaznitsa.com)
 * @version 1.00
 */
public class test extends MIDlet implements Runnable
{
    /**
     * The current display is saved in the variable
     */
    protected Display p_CurrentDisplay;

    /**
     * The working canvas is saved in the variable
     */
    protected Canvas p_MainCanvas;

    protected void startApp() throws MIDletStateChangeException
    {
        if (p_MainCanvas == null)
        {
            p_CurrentDisplay = Display.getDisplay(this);


            // At first we need to check availability of the Nokia FullCanvas
            try
            {
                Class p_class = Class.forName("com.nokia.mid.ui.FullCanvas");

                // We have found the FullCanvas in the middleware so we will use ru.coldcore.NokiaCanvas
                p_class = Class.forName("ru.coldcore.fullcanvas.NokiaCanvas");
                p_MainCanvas = (Canvas) p_class.newInstance();
            }
            catch (Throwable e)
            {
                // Unfortunately there is not NOKIA FullCanvas
                e.printStackTrace();
                p_MainCanvas = null;
            }

            if (p_MainCanvas == null)
            {
                // We are making just ru.coldcore.FullCanvas
                p_MainCanvas = new FullCanvas();
            }
            
            p_CurrentDisplay.setCurrent(p_MainCanvas);

           new Thread(this).start();
        }
    }


    public void run()
    {
        p_MainCanvas.repaint();

        while(true)
        {
            try
            {
                Thread.sleep(100);
            }
            catch (InterruptedException e)
            {
                break;
            }
        }
    }

    protected void pauseApp()
    {

    }

    protected void destroyApp(boolean b) throws MIDletStateChangeException
    {

    }
}
