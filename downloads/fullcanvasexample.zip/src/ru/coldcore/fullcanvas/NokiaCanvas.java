package ru.coldcore.fullcanvas;

import javax.microedition.lcdui.Graphics;

/**
 * The class allows us to use NOKIA FullCanvas
 * @author Igor Maznitsa (igor.maznitsa@igormaznitsa.com)
 * @version 1.00
 */
public class NokiaCanvas extends com.nokia.mid.ui.FullCanvas
{
    /**
     * The variable contains a FullCanvas object
     */
    private FullCanvas p_FullCanvas;

    public NokiaCanvas()
    {
        int i_width = getWidth();
        int i_height = getHeight();
        p_FullCanvas = new FullCanvas(i_width,i_height);
    }

    protected void showNotify()
    {
        if (p_FullCanvas !=null) p_FullCanvas.showNotify();
    }

    protected void hiddenNotify()
    {
        if (p_FullCanvas !=null) p_FullCanvas.hideNotify();
    }
    
    protected void keyPressed(int _key)
    {
        if (p_FullCanvas !=null) p_FullCanvas.keyPressed(_key);
    }

    protected void keyReleased(int _key)
    {
        if (p_FullCanvas !=null) p_FullCanvas.keyReleased(_key);
    }

    protected void paint(Graphics _graphics)
    {
        if (p_FullCanvas !=null) p_FullCanvas.paint(_graphics);

        String s_text = "NOKIA CANVAS";
        _graphics.setColor(0);
        _graphics.drawString(s_text,1,1,Graphics.TOP|Graphics.LEFT);
        _graphics.setColor(0xFFFFFF);
        _graphics.drawString(s_text,0,0,Graphics.TOP|Graphics.LEFT);
    }
}
