I have placed an example of dynamic canvas creation in the archive. The example allows to understand the mechanism that enables to make only application version for working on different devices with full canvas(a full canvas of the example will work on both Nokia and MIDP 2.0 devices). 
Be careful in use of the method because it will not work on devices which have a class checking mechanism because they will not enable to use unavailable classes (as an example is Samsung C100).

(C)2006 Saint-Petersburg,  Igor Maznitsa (igor.maznitsa@igormaznitsa.com)